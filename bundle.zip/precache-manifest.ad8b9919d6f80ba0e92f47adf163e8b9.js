self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "56246f0ad5eeaf3deb948c9a65f7186b",
    "url": "/index.html"
  },
  {
    "revision": "f19ff175702fa6b9af10",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "a56403280912a7b86594",
    "url": "/static/css/main.439b4a20.chunk.css"
  },
  {
    "revision": "f19ff175702fa6b9af10",
    "url": "/static/js/2.13945eff.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.13945eff.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a56403280912a7b86594",
    "url": "/static/js/main.ea216d4a.chunk.js"
  },
  {
    "revision": "6ba5ba2effb9c182ed40",
    "url": "/static/js/runtime-main.b118543b.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);